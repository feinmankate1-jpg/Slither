# Prismcoil

**Chase the glow.** An original, colorful snake survival game made with Phaser 3. Gather glowing sparks, grow your coil, and outlast twelve AI rivals in a large circular arena. All graphics are generated in code. No Slither.io assets, branding, or visual design are used.

## Play in your browser

[Play Prismcoil on GitHub Pages](https://feinmankate1-jpg.github.io/Slither/).

1. Open the game in a modern desktop or mobile browser.
2. Click or tap **Enter the arena**, or press **Space**. This interaction also enables audio.
3. Steer toward glowing sparks to collect points and grow. Avoid other snakes' bodies and the arena rim. Hold the boost control for a temporary burst of speed.
4. When you die, the Game Over screen shows your final score and personal best. Click or tap **Restart the chase**, or press **Space** or **Enter**, to start a new round.

Use the **music-note button** to mute or unmute background music. Use the **speaker button** (or **M**) to mute or unmute sound effects independently.

## Play locally

No dependency installation or build is required. From this directory:

```sh
python3 -m http.server 8000 --bind 0.0.0.0
```

Open [http://localhost:8000/](http://localhost:8000/) on the computer running the server. For a remote development environment, open its forwarded server port. Use an HTTP server rather than opening `index.html` as a file so audio loading works consistently.

## Controls and rules

| Action           | Desktop                                              | Touch                                            |
| ---------------- | ---------------------------------------------------- | ------------------------------------------------ |
| Start / restart  | Click the button or press Space (Enter also restarts) | Tap the button                                   |
| Steer            | Move the mouse toward your destination               | Touch and drag toward your destination           |
| Boost            | Hold the left mouse button or Space                  | Hold the Boost button; steer with another finger |
| Pause / resume   | P, Escape, or the pause button                       | Pause / resume button                            |
| Sound effects    | M or the speaker button                              | Speaker button                                   |
| Background music | Music-note button                                    | Music-note button                                |

- The snake moves continuously and turns smoothly. Your own body is safe to cross.
- Ordinary sparks award **10 points**. Remains from eliminated snakes award **25 points**. Every 30 points adds a body segment, up to 200 segments; points can continue rising after this visual limit.
- Boost lasts about 3.7 seconds on a full charge. Release to recharge. It never reduces your score or length.
- Hit a rival's body head-first, or leave the arena rim, and your round ends immediately. Head-to-head collisions eliminate both snakes.
- New snakes have a brief, visible spawn shield. AI rivals collect food, avoid hazards, leave edible remains when eliminated, and respawn after three seconds.
- Restart resets your score, food, rivals, energy, timer, and length. Your personal best and separate sound-effects/music mute preferences are saved locally when browser storage is available.
- Switching tabs or losing focus pauses the round. No account, backend, or database is needed.

## Custom audio

Three small original synthesized placeholder effects are included. Replace them with your AI-generated MP3s at exactly these paths:

```text
assets/audio/reward.mp3  # Collecting food
assets/audio/damage.mp3  # Collision / elimination
assets/audio/end.mp3     # Game Over appears
```

Audio is initialized and resumed only after a click, tap, or keyboard interaction. A Web Audio tone fallback covers decoding failures. Use short effects (especially reward.mp3), with modest loudness. Sound can be muted; simultaneous rewards are rate-limited.

`assets/audio/background.mp3` contains the supplied ElevenLabs background music. It starts on Start, loops at 25% volume, stops immediately on player death or returning Home, and restarts from the beginning each new round. The music-note button independently mutes/unmutes music and remembers your preference. The speaker button and M shortcut continue to control only sound effects.

## Project structure

```text
index.html               Accessible interface and entry point
style.css                Responsive desktop/mobile interface
src/game.js              Arena, AI, input, spatial grids, rendering, audio
assets/audio/*.mp3        Sound effects and background music
assets/vendor/           Phaser 3.90.0 and its MIT license
README.md
PROMPT_LOG.md            Actual development prompts from the Codex conversation
REFERENCES.md            Sources, audio credits, and tool acknowledgments
```

The only runtime dependency is **Phaser 3.90.0**, bundled locally from its official npm package. Its license is at `assets/vendor/PHASER-LICENSE.txt`. There are no CDN requests, external images, fonts, analytics, or build tools. A modern browser with Canvas or WebGL and Web Audio is recommended; sound remains optional.

## Assignment documentation and credits

[PROMPT_LOG.md](PROMPT_LOG.md) records the actual user prompts available in the Codex conversation, including gameplay, rewards, damage, Game Over, sound effects, deployment, and background music. Confirmation replies are labeled separately; no missing prompts or ElevenLabs generation prompts are invented.

The supplied background music was generated with **[ElevenLabs](https://elevenlabs.io/)**. The current reward, damage, and Game Over effects are synthesized placeholders. See [REFERENCES.md](REFERENCES.md) for audio credits, Phaser references, gameplay inspiration, and Codex assistance.

## GitHub Pages

Commit these files to your repository. In **Settings → Pages**, choose **Deploy from a branch**, your branch, and **/ (root)**. All asset paths are relative, so repository subpaths work. No build step is necessary.

## Itch.io

Zip `index.html`, `style.css`, `src/`, and `assets/` with `index.html` at the ZIP root. Upload as an **HTML** game and select **This file will be played in the browser**. Enable fullscreen and mobile support; use a resizable viewport (suggested desktop embed: 1280 × 800). The game resizes automatically and uses touch controls.

## Development and validation

The `Arena` scene contains a fixed 60 Hz simulation; rendering runs at the browser's refresh rate. Spatial grids accelerate food lookup, AI avoidance, and body collisions. Canvas textures generate all artwork. The UI updates independently of the world camera. Inspect the running scene with `window.prismcoil.game.scene.getScene('Arena')` in developer tools.

After making changes, verify collection increases score and length, boost consumes and restores energy, body collisions end a round, enemy remains are edible, restart restores the initial state, and touch steering works. Check the browser console and both desktop/mobile layouts. Deployment is static: the same checks work under a repository subpath and without Internet access after the files are downloaded.
